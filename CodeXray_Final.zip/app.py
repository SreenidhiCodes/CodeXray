import sys
import os
import streamlit as st

# =========================================================
# PAGE CONFIGURATION
# =========================================================

st.set_page_config(
    page_title="CodeXray",
    page_icon="🔍",
    layout="wide"
)

# =========================================================
# CONNECT FRONTEND TO BACKEND
# =========================================================

sys.path.append(
    os.path.join(os.path.dirname(__file__), "backend")
)

from backend.similarity_engine import compare_codes
from backend.ast_analyzer import normalize_code
from backend.ai_detector import predict_ai_likelihood


# =========================================================
# CUSTOM CSS
# =========================================================

st.markdown(
    """
    <style>

    .main-title {
        font-size: 46px;
        font-weight: 800;
        margin-bottom: 5px;
    }

    .subtitle {
        font-size: 20px;
        font-weight: 500;
        margin-bottom: 30px;
    }

    .feature-box {
        padding: 22px;
        border-radius: 14px;
        border: 1px solid #4a6fa5;
        background-color: #172b4d;
        min-height: 180px;
    }

    .feature-box h3 {
        color: #ffffff !important;
        font-size: 22px;
        font-weight: 700;
        margin-bottom: 12px;
    }

    .feature-box p {
        color: #e6edf7 !important;
        font-size: 16px;
        font-weight: 500;
        line-height: 1.6;
    }

    .section-title {
        font-size: 28px;
        font-weight: 700;
        margin-top: 30px;
        margin-bottom: 18px;
    }

    </style>
    """,
    unsafe_allow_html=True
)


# =========================================================
# SIDEBAR
# =========================================================

st.sidebar.title("🔍 CodeXray")

st.sidebar.caption(
    "AI-Powered Python Code Analysis"
)

st.sidebar.markdown("---")

page = st.sidebar.radio(
    "Navigation",
    [
        "Home",
        "Analyze Code",
        "Compare Codes",
        "Batch Analysis",
        "About"
    ]
)

st.sidebar.markdown("---")

st.sidebar.caption(
    "Python Code Analysis & Similarity Detection"
)


# =========================================================
# HOME
# =========================================================

if page == "Home":

    st.markdown(
        '<div class="main-title">🔍 CODEXRAY</div>',
        unsafe_allow_html=True
    )

    st.markdown(
        '<div class="subtitle">'
        'AI-Powered Python Code Analysis and Similarity Detection'
        '</div>',
        unsafe_allow_html=True
    )

    st.info(
        "Analyze Python programs, compare code similarity, "
        "identify structural similarities and perform batch analysis."
    )

    st.markdown(
        '<div class="section-title">What CodeXray Can Do</div>',
        unsafe_allow_html=True
    )

    col1, col2, col3 = st.columns(3)

    with col1:

        st.markdown(
            """
            <div class="feature-box">

            ### 🧩 Code Analysis

            Analyze Python code and view its
            normalized structure and code statistics.

            </div>
            """,
            unsafe_allow_html=True
        )

    with col2:

        st.markdown(
            """
            <div class="feature-box">

            ### 🔎 Similarity Detection

            Compare two Python programs using
            multiple similarity measures.

            </div>
            """,
            unsafe_allow_html=True
        )

    with col3:

        st.markdown(
            """
            <div class="feature-box">

            ### 📊 Batch Analysis

            Upload multiple Python programs and
            compare them automatically.

            </div>
            """,
            unsafe_allow_html=True
        )

    st.markdown("")

    st.markdown(
        '<div class="section-title">Analysis Techniques</div>',
        unsafe_allow_html=True
    )

    col1, col2, col3, col4 = st.columns(4)

    with col1:
        st.metric("AST", "Analysis")

    with col2:
        st.metric("Text", "Similarity")

    with col3:
        st.metric("Control Flow", "Analysis")

    with col4:
        st.metric("Fingerprint", "Comparison")


# =========================================================
# ANALYZE CODE
# =========================================================

elif page == "Analyze Code":

    st.header("🧩 Analyze Python Code")

    st.write(
        "Enter Python code or upload a `.py` file to analyze it."
    )

    analyze_code = st.text_area(
        "Enter Python Code",
        height=300,
        placeholder="Write or paste Python code here..."
    )

    uploaded_file = st.file_uploader(
        "Or upload a Python file",
        type=["py"],
        key="analyze_upload"
    )

    if uploaded_file is not None:

        analyze_code = uploaded_file.read().decode("utf-8")

        st.write("### Uploaded Code")

        st.code(
            analyze_code,
            language="python"
        )

    if st.button(
        "🔍 Analyze Code",
        type="primary"
    ):

        if not analyze_code.strip():

            st.warning(
                "Please enter or upload Python code."
            )

        else:

            st.success(
                "Code analyzed successfully!"
            )

            # =================================================
            # NORMALIZED CODE
            # =================================================

            st.subheader("Normalized Code")

            normalized = normalize_code(
                analyze_code
            )

            st.code(
                normalized,
                language="python"
            )

            # =================================================
            # AI GENERATION LIKELIHOOD
            # =================================================

            st.subheader(
                "🤖 AI-Generation Likelihood"
            )

            ai_result = predict_ai_likelihood(
                analyze_code
            )

            ai_score = ai_result["display"].split(": ")[1]

            col1, col2, col3 = st.columns(3)

            with col1:

                st.metric(
                    "AI-Generation Likelihood",
                    ai_score
                )

            with col2:

                st.metric(
                    "Method",
                    ai_result["method"].title()
                )

            with col3:

                st.metric(
                    "Confidence",
                    ai_result["confidence"].title()
                )

            # =================================================
            # INDICATORS
            # =================================================

            st.write("### Indicators")

            if ai_result["indicators"]:

                for indicator in ai_result["indicators"]:

                    st.write(
                        "•",
                        indicator
                    )

            else:

                st.info(
                    "No strong AI-style indicators detected."
                )

            st.caption(
                ai_result["disclaimer"]
            )

            # =================================================
            # CODE STATISTICS
            # =================================================

            st.subheader("📊 Code Statistics")

            lines = analyze_code.splitlines()

            total_lines = len(lines)

            blank_lines = sum(
                1
                for line in lines
                if not line.strip()
            )

            code_lines = (
                total_lines -
                blank_lines
            )

            col1, col2, col3 = st.columns(3)

            with col1:

                st.metric(
                    "Total Lines",
                    total_lines
                )

            with col2:

                st.metric(
                    "Code Lines",
                    code_lines
                )

            with col3:

                st.metric(
                    "Blank Lines",
                    blank_lines
                )


# =========================================================
# COMPARE CODES
# =========================================================

elif page == "Compare Codes":

    st.header("🔎 Compare Two Python Programs")

    st.write(
        "Paste two programs or upload two Python files "
        "to compare their similarity."
    )

    # =================================================
    # FILE UPLOAD
    # =================================================

    col1, col2 = st.columns(2)

    with col1:

        file1 = st.file_uploader(
            "Upload Code 1 (.py)",
            type=["py"],
            key="compare_file1"
        )

    with col2:

        file2 = st.file_uploader(
            "Upload Code 2 (.py)",
            type=["py"],
            key="compare_file2"
        )

    # =================================================
    # TEXT INPUT
    # =================================================

    col1, col2 = st.columns(2)

    with col1:

        code1 = st.text_area(
            "Code 1",
            height=300,
            placeholder="Enter first Python program..."
        )

    with col2:

        code2 = st.text_area(
            "Code 2",
            height=300,
            placeholder="Enter second Python program..."
        )

    if file1:

        code1 = file1.read().decode("utf-8")

    if file2:

        code2 = file2.read().decode("utf-8")

    # =================================================
    # COMPARE
    # =================================================

    if st.button(
        "🔍 Compare Code",
        type="primary"
    ):

        if not code1.strip() or not code2.strip():

            st.warning(
                "Please provide both Python programs."
            )

        else:

            result = compare_codes(
                code1,
                code2
            )

            st.success(
                "Comparison completed successfully!"
            )

            # =================================================
            # OVERALL SIMILARITY
            # =================================================

            st.subheader(
                "📊 Similarity Results"
            )

            st.metric(
                "Overall Similarity",
                f"{result['overall_similarity_pct']}%"
            )

            # =================================================
            # COMPONENT SCORES
            # =================================================

            st.write("### Similarity Breakdown")

            col1, col2, col3 = st.columns(3)

            with col1:

                st.metric(
                    "Text Similarity",
                    f"{result['component_scores']['text_similarity'] * 100:.1f}%"
                )

            with col2:

                st.metric(
                    "AST Similarity",
                    f"{result['component_scores']['ast_similarity'] * 100:.1f}%"
                )

            with col3:

                st.metric(
                    "Fingerprint Similarity",
                    f"{result['component_scores']['fingerprint_similarity'] * 100:.1f}%"
                )

            col1, col2, col3 = st.columns(3)

            with col1:

                st.metric(
                    "Control Flow",
                    f"{result['component_scores']['control_flow_similarity'] * 100:.1f}%"
                )

            with col2:

                semantic = result[
                    "component_scores"
                ]["semantic_similarity"]

                if semantic is not None:

                    st.metric(
                        "Semantic Similarity",
                        f"{semantic * 100:.1f}%"
                    )

                else:

                    st.metric(
                        "Semantic Similarity",
                        "Not Available"
                    )

            with col3:

                st.metric(
                    "Overall Score",
                    f"{result['overall_similarity_pct']}%"
                )

            # =================================================
            # EVIDENCE
            # =================================================

            st.subheader(
                "🔍 Evidence Detected"
            )

            if result["evidence"]:

                for evidence in result["evidence"]:

                    st.write(
                        "•",
                        evidence
                    )

            else:

                st.info(
                    "No strong similarity patterns detected."
                )

            # =================================================
            # APPROACH ANALYSIS
            # =================================================

            st.subheader(
                "🧠 Approach Analysis"
            )

            approach = result[
                "approach_analysis"
            ]

            col1, col2, col3 = st.columns(3)

            with col1:

                st.write(
                    "**Code 1 Approach**"
                )

                st.info(
                    approach["code1_approach"]
                )

            with col2:

                st.write(
                    "**Code 2 Approach**"
                )

                st.info(
                    approach["code2_approach"]
                )

            with col3:

                st.write(
                    "**Same Approach**"
                )

                st.info(
                    str(
                        approach["same_approach"]
                    )
                )


# =========================================================
# BATCH ANALYSIS
# =========================================================

elif page == "Batch Analysis":

    st.header("📊 Batch Analysis")

    st.write(
        "Upload multiple Python files to analyze and "
        "compare them automatically."
    )

    files = st.file_uploader(
        "Upload Python files",
        type=["py"],
        accept_multiple_files=True,
        key="batch_upload"
    )

    if files:

        st.success(
            f"Uploaded {len(files)} file(s)."
        )

        # =================================================
        # READ FILES
        # =================================================

        file_codes = {}

        for file in files:

            code = file.read().decode("utf-8")

            file_codes[file.name] = code

        # =================================================
        # UPLOADED FILES
        # =================================================

        st.subheader(
            "📁 Uploaded Files"
        )

        for filename in file_codes:

            st.write(
                "•",
                filename
            )

        # =================================================
        # NORMALIZED CODE
        # =================================================

        st.subheader(
            "🧩 Normalized Code"
        )

        for filename, code in file_codes.items():

            with st.expander(
                filename
            ):

                normalized = normalize_code(
                    code
                )

                st.code(
                    normalized,
                    language="python"
                )

        # =================================================
        # COMPARE FILES
        # =================================================

        if len(file_codes) >= 2:

            st.subheader(
                "🔎 Pairwise Similarity Results"
            )

            filenames = list(
                file_codes.keys()
            )

            for i in range(
                len(filenames)
            ):

                for j in range(
                    i + 1,
                    len(filenames)
                ):

                    file1 = filenames[i]

                    file2 = filenames[j]

                    result = compare_codes(
                        file_codes[file1],
                        file_codes[file2]
                    )

                    st.markdown(
                        f"### {file1} ↔ {file2}"
                    )

                    st.metric(
                        "Overall Similarity",
                        f"{result['overall_similarity_pct']}%"
                    )

                    col1, col2, col3 = st.columns(3)

                    with col1:

                        st.write(
                            "AST Similarity"
                        )

                        st.write(
                            f"{result['component_scores']['ast_similarity'] * 100:.1f}%"
                        )

                    with col2:

                        st.write(
                            "Text Similarity"
                        )

                        st.write(
                            f"{result['component_scores']['text_similarity'] * 100:.1f}%"
                        )

                    with col3:

                        st.write(
                            "Control Flow"
                        )

                        st.write(
                            f"{result['component_scores']['control_flow_similarity'] * 100:.1f}%"
                        )

                    st.divider()

        else:

            st.info(
                "Upload at least 2 Python files "
                "to compare them."
            )

    else:

        st.info(
            "Upload Python files above to begin batch analysis."
        )


# =========================================================
# ABOUT
# =========================================================

elif page == "About":

    st.header("ℹ️ About CodeXray")

    st.write(
        "CodeXray is an AI-powered Python code analysis "
        "and similarity detection system."
    )

    st.subheader(
        "Project Purpose"
    )

    st.write(
        "The system is designed to analyze Python programs "
        "and identify similarities using multiple code analysis "
        "techniques."
    )

    st.subheader(
        "Main Features"
    )

    st.write(
        """
        • Python code analysis

        • Code normalization

        • AI-generation likelihood indicator

        • Text similarity analysis

        • AST-based structural similarity

        • Logic fingerprint comparison

        • Control-flow similarity analysis

        • Approach analysis

        • Batch code comparison
        """
    )

    st.subheader(
        "Technology"
    )

    st.write(
        """
        • Python

        • Streamlit

        • Abstract Syntax Tree (AST) analysis

        • Code similarity analysis

        • Machine learning / AI-based analysis
        """
    )

    st.success(
        "CodeXray — AI-Powered Python Code Analysis"
    )